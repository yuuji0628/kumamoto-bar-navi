KUMAMOTO BAR NAVI v3

今回の修正
- スマホのメイン見出しの改行を調整
- 黄色い検索ボタンの文字色を黒に固定
- KUMAMOTO BAR NAVIのロゴ画像を正式反映
- Instagramリンクをヘッダー・フッター・Instagram欄に追加
- スマホ表示のロゴサイズを最適化

Cloudflareへアップロードするファイル
- index.html
- style.css
- script.js
- assets/logo.png

※ assets フォルダも必ずアップロードしてください。
※ Instagram URLは @kumamoto_bar_navi を設定しています。
